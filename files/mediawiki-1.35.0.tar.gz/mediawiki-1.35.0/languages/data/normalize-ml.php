<?php
// File created by generateNormalizerDataMl.php
return [
	'ണ്‍' => 'ൺ',
	'ന്‍' => 'ൻ',
	'ര്‍' => 'ർ',
	'ല്‍' => 'ൽ',
	'ള്‍' => 'ൾ',
	'ക്‍' => 'ൿ',
];
